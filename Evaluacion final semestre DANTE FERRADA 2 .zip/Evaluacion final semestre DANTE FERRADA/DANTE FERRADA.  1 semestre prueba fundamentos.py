#==================================
#    DICCIONARIO PHYTON 
#==================================
productos = {'M001':['Alimento Premium', 'comida', 'DogPlus', 10, True, False],
             'M002': ['Arena Aglomerante', 'higiene', 'CatClean', 8, False, False],
             'M003': ['Snack Dental', 'snack', 'BiteJoy', 1, True, True],
             'M004': ['Shampoo Suave', 'higiene', 'PetCare', 0.5, False, True],
             'M005': ['Correa Nylon', 'accesorio', 'WalkPro', 0.3, True, False],
             'M006': ['Cama Mediana', 'accesorio', 'CozyPet', 2, False, False]
}


stock = {
             'M001': [32990, 12],
             'M002': [9990, 0],
             'M003': [5490, 25],
             'M004': [7990, 5],
             'M005': [11990, 7],
             'M006': [24990, 3],
  
}



#=====================================
#      DEFINIR VALIDACIONES 
#=====================================
def validar_codigo(codigo):
    if codigo.strip() == "":
        return False
    if codigo.upper() in productos:
        return False
    return True


def validar_nombre(nombre):
    return nombre.strip()!=""


def validar_categoria(categoria):
    return categoria.strip()!=""


def validar_marca(marca):
    return marca.strip()!=""


def validar_peso(peso):
    return peso>0


def validar_importado(valor):
    return valor.lower()=="s" or valor.lower()=="n"


def validar_cachorros(valor):
    return valor.lower()=="s" or valor.lower()=="n"


def validar_precio(precio):
    return precio>0


def validar_unidades(unidades):
    return unidades>=0

#===================
#   Menu
#===================

def mostrar_menu():
  print("\n =========MENU PRINCIPAL=============")
  print("1. Unidades por categoria")
  print("2. Busqueda de productos por rango de precio ")
  print("3. Actualizar precio de producto ")
  print("4. Agregar producto ")
  print("5. Eliminar producto ")
  print("6. Salir ")
  print("=====================================")

def leer_opcion():

    while True:

        try:

            opcion = int(input("Ingrese una opcion: "))

            if 1 <= opcion <= 6:
                return opcion

            print("Debe seleccionar una opcion valida")

        except ValueError:
            print("Debe seleccionar una opcion valida")

#==================================
#         OPCION 1
#=================================
def unidades_categoria(categoria):

    total=0

    for codigo in productos:

      if productos[codigo][1].lower() == categoria.lower():
            total += stock[codigo][1]

    print("El total de unidades disponibles es:", total)


# ==============================
#       OPCION 2
# ==============================

def busqueda_precio(p_min, p_max):

    lista=[]

    for codigo in stock:

        precio = stock[codigo][0]
        unidades = stock[codigo][1]

        if p_min <= precio <= p_max and unidades > 0:

          lista.append(productos[codigo][0] +"--"+ codigo)

    lista.sort()

    if len(lista) == 0:
      print("no hay productos en ese rango de precios:")
    else:
      print(lista)

# ==========================
#     OPCION 3
# ==========================

def actualizar_precio(codigo, nuevo_precio):

    codigo=codigo.upper()

    if codigo in stock:

        stock[codigo][0] = nuevo_precio
        return True

    return False

# ==========================
#     OPCION 4
# ==========================

def agregar_producto(codigo,nombre,categoria,marca,peso,importado,cachorro,precio,unidades):

    codigo=codigo.upper()

    if codigo in productos:
        return False

    productos[codigo] = [
        nombre,
        categoria,
        marca,
        peso,
        importado,
        cachorro,
    ]

    stock[codigo] =[precio,unidades]

    return True

#================================
#    OPCION 5
#================================

def eliminar_producto(codigo):

    codigo = codigo.upper()

    if codigo in productos:

        del productos[codigo]
        del stock[codigo]

        return True

    return False

# ===========================================================
#     PROGRAMA PRINCIPAL CON SUS OPCIONES A ESCOGER
# ===========================================================

while True:

    mostrar_menu()
    opcion=leer_opcion()
#==========================
#       OPCION 1
#==========================

    if opcion == 1:

          categoria = input("Ingrese categoria: ")
          unidades_categoria(categoria)

# ==========================
#       OPCION 2
# ==========================

    elif opcion == 2:

        while True:

            try:
                p_min=int(input("Ingrese un precio minimo: "))
                p_max=int(input("Ingrese un precio maximo: "))

                if p_min<=p_max:
                  break

                print("el precio debe ser menor o igual al maximo")
            except ValueError:
                print("Debe ingresar numeros entero")

        busqueda_precio(p_min, p_max)

    # ==========================
    #     OPCION 3
    # ==========================

    elif opcion == 3:
        seguir="s"

        while seguir.lower()=="s":
            codigo =input("ingrese codigo: ")

            try:
                nuevo_precio = int(input("Ingrese nuevo precio: "))
            except ValueError:
                print("Debe ingresar un numero entero.")
                continue

            if actualizar_precio(codigo, nuevo_precio):
                print("Precio ya actualizado ")
            else:
              print("el codigo no existe ")


            seguir =input("¿Desea actualizar otro precio? (s/n): ")

# ======================
#     OPCION 4
# ======================

    elif opcion == 4:

        codigo = input("Ingrese codigo: ")
        if not validar_codigo(codigo):
            print("Codigo invalido o ya existe")
            continue



        nombre = input("Ingrese nombre: ")
        if not validar_nombre(nombre):
            print("Nombre invalido")
            continue



        categoria = input("Ingrese una categoria: ")

        if not validar_categoria(categoria):
            print("Categoria invalida")
            continue



        marca = input("Ingrese marca: ")
        if not validar_marca(marca):
            print("Marca invalida")
            continue



        try:
            peso = float(input("Ingrese peso: "))
        except ValueError:
            print("Peso invalido")
            continue
        if not validar_peso(peso):
            print("Peso invalido")
            continue





        importado = input("¿Es importado? (s/n): ")

        if not validar_importado(importado):
            print("Valor invalido")
            continue




        cachorro = input("¿Es para cachorros? (s/n): ")

        if not validar_cachorros(cachorro):
            print("Valor invalido")
            continue



        try:
            precio = int(input("Ingrese precio: "))
        except ValueError:
            print("Precio invalido")
            continue
        if not validar_precio(precio):
            print("Precio invalido")
            continue



        try:
            unidades = int(input("Ingrese unidades: "))
        except ValueError:
            print("Unidades invalidas")
            continue
        if not validar_unidades(unidades):
            print("Unidades invalidas")
            continue



        importado = importado.lower() == "s"
        cachorro = cachorro.lower() == "s"

        if agregar_producto(codigo,nombre,categoria,marca,peso,importado,cachorro,precio,unidades):
            print("producto agregado correctamente ")          
        else:
            print("El codigo existe")

# ==========================
#         OPCION 5
# ==========================

    elif opcion == 5:

        codigo = input("Ingrese codigo: ")

        if eliminar_producto(codigo):
            print("Producto eliminado")
        else:
            print("El codigo no existe")

# ==========================
# OPCION 6
# ==========================

    else:

        print("Programa finalizando.................")
        break